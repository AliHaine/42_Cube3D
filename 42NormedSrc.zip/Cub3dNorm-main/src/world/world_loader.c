/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   world_loader.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/02 12:35:56 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/02 12:35:57 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

bool	world_malloc(int height, int width, char ***map)
{
	int	i;

	i = 0;
	(*map) = malloc(sizeof(char *) * (height + 1));
	if (!*map)
		return (false);
	(*map)[height] = 0;
	while (i < height)
	{
		(*map)[i] = malloc(sizeof(char) * width + 1);
		if (!(*map)[i])
			return (false);
		(*map)[i][width] = 0;
		i++;
	}
	return (true);
}

void	world_generator(t_swo *world)
{
	int	i;

	i = -1;
	while (i++ < 8)
		chunk_generator(world, i);
}

static t_sbi	**wgb(int biome_number, ...)
{
	t_sbi	**biomes;
	va_list	va_biomes;

	va_start(va_biomes, biome_number);
	biomes = malloc(sizeof(t_sbi *) * (biome_number + 1));
	biomes[biome_number] = 0;
	while (biome_number-- > 0)
		biomes[biome_number] = va_arg(va_biomes, t_sbi *);
	va_end(va_biomes);
	return (biomes);
}

void	world_loader(t_core *core)
{
	biome_loader();
	wc1(WOB, wgb(3, gb(BIB), gb(BID), gb(BIE)), get_sound(SOB));
	wc2(WOB, 32, 32, (uint32_t []){0, 0});
	wc3(WOB, core->imgs.skybox_nether, get_block_image(BLB), HARD);
	wc4(WOB, false, core->options.sprites, true);
	wc1(WOC, wgb(2, gb(BIF), gb(BIG)), get_sound(SOC));
	wc2(WOC, 32, 32, (uint32_t []){0, 0});
	wc3(WOC, core->imgs.skybox_end, get_block_image(BLW), NORMAL);
	wc4(WOC, false, core->options.sprites, true);
	wc1(WOD, wgb(1, gb(BIC)), get_sound(SOD));
	wc2(WOD, 32, 32, (uint32_t []){0, 0});
	wc3(WOD, core->imgs.backrooms_ceil, get_block_image(BLJ), HARD);
	wc4(WOD, false, core->options.sprites, false);
}
