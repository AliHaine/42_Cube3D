/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   world_utils.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 22:26:14 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/17 22:26:17 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

void	change_active_world(t_swo	*new_world)
{
	t_swo	*old_world;

	old_world = get_world_active();
	if (new_world->n == old_world->n)
		new_world = gw(WOA);
	stop_sound(old_world->s);
	old_world->a = false;
	new_world->a = true;
	play_sound(new_world->s);
}

void	replace_on_world(float coords[][2], int num, t_swo *world)
{
	if (num == 1)
		coords[0][1] += world->h * 64;
	else if (num == 3)
		coords[0][0] += world->y * 64;
	else if (num == 5)
		coords[0][0] -= world->y * 64;
	else if (num == 7)
		coords[0][1] -= world->h * 64;
}
