/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   world_loader.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/02 12:35:56 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/02 12:35:57 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

void	wc1(t_ewo world_name, t_sbi **biomes, t_sso *ambient_sound)
{
	gw(world_name)->n = world_name;
	gw(world_name)->b = biomes;
	gw(world_name)->s = ambient_sound;
}

void	wc2(t_ewo world_name, int height, int width, const uint32_t bt_color[2])
{
	gw(world_name)->h = height;
	gw(world_name)->y = width;
	gw(world_name)->o[0] = bt_color[0];
	gw(world_name)->o[1] = bt_color[1];
}

void	wc3(t_ewo wn, mlx_image_t *ceil, mlx_image_t *floor, t_sdi difficulty)
{
	gw(wn)->p = ceil;
	gw(wn)->f = floor;
	gw(wn)->d = difficulty;
}

void	wc4(t_ewo wn, bool is_active, bool sprites, bool s)
{
	int	i;

	i = 0;
	gw(wn)->a = is_active;
	gw(wn)->m = s;
	gw(wn)->w = malloc(sizeof(char **) * 9);
	if (sprites)
		gw(wn)->z = malloc(sizeof(t_ssp **) * 9);
	else
		gw(wn)->z = NULL;
	while (i < 9)
	{
		if (sprites)
			gw(wn)->z[i] = NULL;
		world_malloc(gw(wn)->h * 3, gw(wn)->y * 3, &gw(wn)->w[i++]);
	}
	world_generator(gw(wn));
	sprites_generator(gw(wn));
}
