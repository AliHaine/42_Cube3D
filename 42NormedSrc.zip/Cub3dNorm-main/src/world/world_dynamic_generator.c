/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   world_dynamic_generator.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/27 14:40:18 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/27 14:40:20 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/concepts/world.h"

static void	wplacemap2(t_swo *w, int c, int mul, int inc)
{
	int	i;

	i = -1;
	c += inc;
	while (i++ < 2)
		copy_tab(w->w[(c + i * mul) + inc], w->w[c + i * mul], w->h, w->y);
}

static void	world_place_map(t_swo *w, int chunk_num, int i, int mul)
{
	int	inc;
	int	c;

	c = 0;
	if (chunk_num == 1)
	{
		c = 6;
		inc = -3;
	}
	else if (chunk_num == 7)
		inc = 3;
	else if (chunk_num == 3)
	{
		mul = 3;
		c = 2;
		inc = -1;
	}
	else
	{
		mul = 3;
		inc = 1;
	}
	while (i++ < 2)
		copy_tab(w->w[(c + i * mul) + inc], w->w[c + i * mul], w->h, w->y);
	wplacemap2(w, c, mul, inc);
}

static void	side_generator(t_swo *world, int chunk_num)
{
	int	i;
	int	chunk;
	int	incrementation;

	i = -1;
	chunk = 0;
	if (chunk_num == 3 || chunk_num == 5)
	{
		incrementation = 3;
		if (chunk_num == 5)
			chunk = 2;
	}
	else
	{
		incrementation = 1;
		if (chunk_num == 7)
			chunk = 6;
	}
	while (i++ < 2)
		chunk_generator(world, chunk + (incrementation * i));
}

static int	get_chunk_from_corner(int iterator, int chunk_num)
{
	if (iterator == 1)
	{
		if (chunk_num == 0 || chunk_num == 2)
			return (1);
		else
			return (7);
	}
	else
	{
		if (chunk_num == 0 || chunk_num == 6)
			return (3);
		else if (chunk_num == 2 || chunk_num == 8)
			return (5);
	}
	return (chunk_num);
}

bool	world_dynamic_generator(t_spl *player)
{
	int		start_chunk;
	int		chunk;
	t_swo	*world;
	int		iterator;

	world = get_world_active();
	start_chunk = gcfp(player->pc[0], player->pc[1]);
	iterator = 1;
	if (is_chunk_on_corner(start_chunk))
		iterator = 2;
	while (iterator-- > 0)
	{
		chunk = get_chunk_from_corner(iterator, start_chunk);
		world_place_map(world, chunk, -1, 1);
		side_generator(world, chunk);
		replace_on_world(&player->pp, chunk, world);
		sprites_place(world, chunk);
	}
	return (0);
}
