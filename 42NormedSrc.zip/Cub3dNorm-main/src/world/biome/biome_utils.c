/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   biome_utils.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/20 23:39:24 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/20 23:39:26 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/includes.h"

int	get_biomes_size(t_sbi **biomes)
{
	int	i;

	i = 0;
	if (!biomes)
		return (0);
	while (*(biomes++))
		i++;
	return (i);
}

t_sbi	*get_random_biome(t_sbi **biomes)
{
	int	biomes_size;

	biomes_size = get_biomes_size(biomes);
	if (biomes_size == 0)
		return (0);
	return (biomes[r(biomes_size, 1)]);
}

t_sbl	grbfb(t_sbi *biome)
{
	return (biome->b[r(biome->bn, 1)]);
}
