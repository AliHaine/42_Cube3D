/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   biome_accessor.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/22 22:22:11 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/22 22:22:46 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/includes.h"

static t_sbi			g_biomes[BIH];

t_sbi	*gb(t_ebi biome)
{
	return (&g_biomes[biome]);
}

void	set_biome(t_sbi biome, int num)
{
	g_biomes[num] = biome;
}

void	free_biome(void)
{
	int	i;

	i = BIH;
	while (i-- > 0)
		free(gb(i)->b);
}
