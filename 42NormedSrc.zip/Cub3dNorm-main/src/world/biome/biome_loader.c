/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   biome_loader.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/02 16:17:47 by ayagmur           #+#    #+#             */
/*   Updated: 2023/09/02 16:17:48 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/includes.h"

static t_sbi	biome_creator(int block_number, ...)
{
	t_sbi	biome;
	va_list	va_biome;

	va_start(va_biome, block_number);
	biome.b = malloc(sizeof(t_sbl) * block_number);
	biome.bn = block_number;
	while (block_number-- > 0)
		biome.b[block_number] = *get_block(va_arg(va_biome, t_ebl));
	va_end(va_biome);
	return (biome);
}

void	biome_loader(void)
{
	set_biome(biome_creator(6, BLB, BLG, BLC, BLD, BLE, BLF), BIB);
	set_biome(biome_creator(1, BLI), BIC);
	set_biome(biome_creator(4, BLL, BLM, BLN, BLO), BID);
	set_biome(biome_creator(4, BLP, BLR, BLS, BLT), BIE);
	set_biome(biome_creator(2, BLX, BLW), BIF);
	set_biome(biome_creator(3, BL0, BLZ, BLY), BIG);
}
