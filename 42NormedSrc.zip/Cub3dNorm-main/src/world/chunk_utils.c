/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   chunk_utils.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/22 22:23:37 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/22 22:23:39 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

int	gcfp(int x, int y)
{
	int		cell;
	int		line;
	t_swo	*world;

	cell = -1;
	line = -1;
	world = get_world_active();
	if (y > (world->h * 3) || x > (world->y * 3))
		return (-1);
	while (line++ < 2)
	{
		if (y < (world->h * (line + 1)))
		{
			while (cell++ < 2)
				if (x < (world->y * (cell + 1)))
					return (cell + (line * 3));
		}
	}
	return (0);
}

bool	is_chunk_change(int cells[][2], t_swo *world)
{
	if (cells[0][0] >= (world->y) && cells[0][0] <= ((world->y * 2) - 1)
		&& cells[0][1] >= (world->h)
		&& cells[0][1] <= ((world->h * 2) - 1))
		return (false);
	return (true);
}

void	chunk_generator(t_swo *world, int chunk)
{
	int		y;
	int		x;
	t_sbi	*biome;

	y = -1;
	x = -1;
	biome = get_random_biome(world->b);
	while (y++ < world->h)
	{
		while (x++ < world->y)
		{
			world->w[chunk][y][x] = '0';
			if (!r(10, 1))
			{
				if (!r(10000, 1))
					world->w[chunk][y][x] = '(';
				else if (biome != NULL)
					world->w[chunk][y][x] = grbfb(biome).bc;
				else
					world->w[chunk][y][x] = '1';
			}
		}
		x = -1;
	}
}

bool	is_chunk_on_corner(int chunk_num)
{
	if (chunk_num == 0 || chunk_num == 2
		|| chunk_num == 6 || chunk_num == 8)
		return (true);
	return (false);
}
