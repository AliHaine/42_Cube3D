/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   world_accessor.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/22 22:23:49 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/22 22:23:50 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/concepts/world.h"

static t_swo			g_worlds[WOF];

t_swo	*gw(int num)
{
	return (&g_worlds[num]);
}

t_swo	*get_world_active(void)
{
	int	i;

	i = WOF;
	while (i-- > 0)
		if (gw(i)->a)
			return (gw(i));
	return (0);
}

void	set_world(t_swo world, int num)
{
	g_worlds[num] = world;
}

void	free_world(void)
{
	int		i;
	t_swo	*world;

	i = WOF;
	while (i-- > 0)
	{
		world = gw(i);
		free_all_sprites(world);
		free_tab_three(world->w);
		free(world->b);
	}
}
