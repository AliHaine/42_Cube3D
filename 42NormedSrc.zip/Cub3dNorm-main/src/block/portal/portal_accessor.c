/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   portal_accessor.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/03 19:22:06 by ayagmur           #+#    #+#             */
/*   Updated: 2023/09/03 19:22:07 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/concepts/portal.h"

static t_spo	g_portals[PO9];

t_spo	*get_portal(t_epo portal)
{
	return (&g_portals[portal]);
}

t_spo	*gpfc(char c)
{
	int	i;

	i = -1;
	while (++i < PO9)
		if (get_portal(i)->b->bc == c)
			return (get_portal(i));
	return (0);
}

void	set_portal(t_spo portal)
{
	g_portals[portal.n] = portal;
}
