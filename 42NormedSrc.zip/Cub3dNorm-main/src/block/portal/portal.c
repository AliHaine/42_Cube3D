/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   portal.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/20 01:09:06 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/20 01:09:08 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/concepts/portal.h"

static bool	is_player_under_portal(const int pc[2], const t_swo *w)
{
	if (!gpfc(w->w[4][pc[1] % w->h][pc[0] % w->y]))
		return (false);
	return (true);
}

void	portal_listener(t_spl *p, t_swo *w)
{
	if (!is_player_under_portal(p->pc, w))
		return ;
	change_active_world(gpfc(w->w[4][p->pc[1] % w->h][p->pc[0] % w->y])->d);
	teleport_player(p);
}

void	portal_open(t_spl *player)
{
	set_char_at_forward(get_block(BLA)->bc, player);
}

void	portal_close(t_spl *player)
{
	set_char_at_forward(get_block(BLD)->bc, player);
}
