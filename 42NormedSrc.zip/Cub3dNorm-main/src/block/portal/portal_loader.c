/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   portal_loader.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/03 18:35:32 by ayagmur           #+#    #+#             */
/*   Updated: 2023/09/03 18:35:34 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/concepts/portal.h"

/* Create a new portal
 *
 * @param portal	The enum value of the portal
 * @param world		The enum value of the world destination
 * @param block		The enum value of the block who is the portal */

void	create_portal(t_epo portal, t_ewo world, t_ebl block)
{
	t_spo	new_portal;

	new_portal.n = portal;
	new_portal.d = gw(world);
	new_portal.b = get_block(block);
	set_portal(new_portal);
}

void	portal_loader(void)
{
	create_portal(POA, WOB, BLA);
	create_portal(POB, WOC, BLV);
	create_portal(POC, WOD, BLK);
}
