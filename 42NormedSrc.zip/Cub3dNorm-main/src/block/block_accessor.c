/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   block_accessor.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/23 22:50:38 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/23 22:50:39 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/concepts/block.h"

static t_sbl	*g_blocks[BL9];

t_sbl	*get_block(t_ebl block)
{
	return (g_blocks[block]);
}

t_sbl	*gbfc(char block_char)
{
	int	i;

	i = BL9;
	while (i-- > 0)
	{
		if (g_blocks[i]->bc == block_char)
			return (g_blocks[i]);
	}
	return (0);
}

t_ebl	gbnfc(char block_char)
{
	int	i;

	i = BL9;
	while (i-- > 0)
	{
		if (g_blocks[i]->bc == block_char)
			return (g_blocks[i]->n);
	}
	return (0);
}

mlx_image_t	*get_block_image(t_ebl block)
{
	return (g_blocks[block]->i);
}

void	set_block(t_sbl *block)
{
	g_blocks[block->n] = block;
}
