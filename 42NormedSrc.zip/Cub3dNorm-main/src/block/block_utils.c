/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   block_utils.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 00:17:09 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/25 00:17:10 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/concepts/block.h"

bool	is_rigid_block(t_ebl block)
{
	return (get_block(block)->r);
}

bool	is_char_block(char c)
{
	if (!gbfc(c))
		return (false);
	return (true);
}
