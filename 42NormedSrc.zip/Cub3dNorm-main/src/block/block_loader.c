/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   block_loader.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/31 17:17:23 by ayagmur           #+#    #+#             */
/*   Updated: 2023/07/31 17:17:25 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

static void	create_block(t_ebl b, int s, mlx_t *m, char c)
{
	char	*path;
	t_sbl	*block;

	block = malloc(sizeof(t_sbl));
	block->n = b;
	block->s = s;
	block->bc = c;
	block->a.is_playing = false;
	path = malloc(sizeof(char) * (ft_strlen(g_b_n[b]) + 19));
	pts(path, "assets/blocks/", g_b_n[b], 0);
	if (!sifp(m, path, &block->i))
		msg_write(2, 2, ERROR_FATAL);
	free(path);
	set_block(block);
}

static void	cba(t_sbl *b, int a, mlx_t *mlx, int i)
{
	char	*path;

	b->a.is_playing = true;
	b->a.depth_xy[0] = 0;
	b->a.depth_xy[1] = 0;
	b->a.image = malloc(sizeof(mlx_image_t) * (a + 1));
	path = malloc(sizeof(char) * (ft_strlen(g_b_n[b->n]) + 20));
	while (i++ < a)
	{
		pts(path, "assets/blocks/", g_b_n[b->n], ft_itoa(i));
		if (!sifp(mlx, path, &b->a.image[i - 1]))
		{
			free(path);
			msg_write(2, 2, ERROR_FATAL);
		}
		mlx_image_to_window(mlx, b->a.image[i - 1], S_W / 1.4, S_H - 290);
		b->a.image[i - 1]->instances[0].enabled = false;
		b->a.image[i - 1]->instances[0].z = 8;
		free(path);
		path = malloc(sizeof(char) * (ft_strlen(g_b_n[b->n]) + 21));
	}
	free(path);
	b->a.image[i - 1] = 0;
}

static void	bl3(void)
{
	gbfc('N')->r = true;
	gbfc('B')->r = true;
	gbfc('D')->r = true;
	gbfc('?')->r = true;
	gbfc('=')->r = true;
	gbfc('+')->r = true;
	gbfc('|')->r = true;
	gbfc('}')->r = true;
	gbfc('{')->r = true;
	gbfc('T')->r = false;
	gbfc('$')->r = false;
	gbfc('x')->r = true;
	gbfc('X')->r = true;
	gbfc('k')->r = true;
	gbfc('K')->r = true;
	gbfc('l')->r = true;
}

static void	bl2(mlx_t *mlx)
{
	create_block(BLS, 69, mlx, '}');
	create_block(BLT, 68, mlx, '{');
	create_block(BLU, 0, mlx, 'T');
	create_block(BLV, 350, mlx, '$');
	create_block(BLW, 45, mlx, 'x');
	create_block(BLX, 80, mlx, 'X');
	create_block(BLY, 45, mlx, 'k');
	create_block(BLZ, 150, mlx, 'K');
	create_block(BL0, 85, mlx, 'l');
	gbfc('Z')->r = false;
	gbfc('R')->r = true;
	gbfc('O')->r = true;
	gbfc('L')->r = true;
	gbfc('P')->r = true;
	gbfc('I')->r = true;
	gbfc('Y')->r = true;
	gbfc('@')->r = true;
	gbfc('[')->r = true;
	gbfc(']')->r = true;
	gbfc('(')->r = false;
}

void	block_loader(mlx_t *mlx)
{
	create_block(BLA, 1, mlx, 'Z');
	cba(get_block(BLA), 14, mlx, 0);
	create_block(BLB, 10, mlx, 'R');
	create_block(BLC, 120, mlx, 'O');
	create_block(BLD, 150, mlx, 'L');
	create_block(BLE, 140, mlx, 'P');
	create_block(BLF, 80, mlx, 'I');
	create_block(BLG, 85, mlx, 'Y');
	create_block(BLH, 2, mlx, '@');
	create_block(BLI, 55, mlx, '[');
	create_block(BLJ, 45, mlx, ']');
	create_block(BLK, 0, mlx, '(');
	create_block(BLL, 45, mlx, 'N');
	create_block(BLM, 45, mlx, 'B');
	create_block(BLN, 120, mlx, 'D');
	create_block(BLO, 150, mlx, '?');
	create_block(BLP, 95, mlx, '=');
	create_block(BLQ, 45, mlx, '+');
	create_block(BLR, 65, mlx, '|');
	bl2(mlx);
	bl3();
}
