/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cub3d.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ngalzand <ngalzand@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/11 16:47:42 by ngalzand          #+#    #+#             */
/*   Updated: 2023/08/16 11:17:34 by ngalzand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/includes.h"

static void	mlx_hook_loader(t_core *core)
{
	mlx_loop_hook(core->mlx, &display, core);
	mlx_loop_hook(core->mlx, &inputs, core);
	mlx_loop_hook(core->mlx, &player_listener, core);
	mlx_key_hook(core->mlx, &inputs_hook, core);
	mlx_resize_hook(core->mlx, &resize_hook, core);
	mlx_mouse_hook(core->mlx, &mouse, core);
	mlx_scroll_hook(core->mlx, &scroll_hook, core);
	mlx_loop_hook(core->mlx, &inventory_hook, core);
	mlx_loop(core->mlx);
}

static void	imgs_init(mlx_t *mlx, t_imgs *imgs)
{
	imgs->wall_texture[0] = 0;
	imgs->wall_texture[1] = 0;
	imgs->wall_texture[2] = 0;
	imgs->wall_texture[3] = 0;
	imgs->img_3d = mlx_new_image(mlx, S_W, S_H);
	imgs->ig = mlx_texture_to_image(mlx, imgs->igt);
	imgs->img_player = mlx_texture_to_image(mlx, imgs->img_player_texture);
}

void	init_gui(t_core *c)
{
	c->imgs.img_3d = mlx_new_image(c->mlx, S_W, S_H);
	mlx_set_cursor(c->mlx, mlx_create_cursor(c->imgs.trans));
	mlx_image_to_window(c->mlx, c->imgs.crosshair, S_W / 2, S_H / 2);
	mlx_image_to_window(c->mlx, c->imgs.invbar, S_W / 3.43, S_H - 95);
	mlx_image_to_window(c->mlx, c->imgs.invbar_selector, S_W / 3.43, S_H - 95);
	mlx_image_to_window(c->mlx, c->imgs.engbar, S_W / 3, S_H - 115);
	draw_energy_bar(c->imgs.engbar, 100, 3, 1);
	mlx_image_to_window(c->mlx, c->imgs.hearth[0], S_W / 2.9, S_H - 155);
	mlx_image_to_window(c->mlx, c->imgs.hearth[0], S_W / 2.69, S_H - 155);
	mlx_image_to_window(c->mlx, c->imgs.hearth[0], S_W / 2.51, S_H - 155);
	mlx_image_to_window(c->mlx, c->imgs.hearth[1], S_W / 2.9, S_H - 155);
	mlx_image_to_window(c->mlx, c->imgs.hearth[1], S_W / 2.69, S_H - 155);
	mlx_image_to_window(c->mlx, c->imgs.hearth[1], S_W / 2.51, S_H - 155);
	c->imgs.hearth[0]->instances[0].z = 11;
	c->imgs.hearth[0]->instances[1].z = 11;
	c->imgs.hearth[0]->instances[2].z = 11;
	c->imgs.hearth[1]->instances[0].z = 12;
	c->imgs.hearth[1]->instances[1].z = 12;
	c->imgs.hearth[1]->instances[2].z = 12;
	mlx_image_to_window(c->mlx, c->imgs.ig, 0, 0);
	c->imgs.ig->enabled = false;
	c->imgs.hearth[0]->enabled = 1;
	c->imgs.hearth[1]->enabled = 1;
}

static void	core_init(t_core *c)
{
	msg_write(1, -1, CORE_INIT);
	initialize_options(c);
	mlx_set_setting(MLX_STRETCH_IMAGE, true);
	c->mlx = mlx_init(S_W, S_H, "セグメンテーションフォルトのないプログラムは、鋭い剣のように正確に使える。", true);
	texture_loader(c);
	imgs_init(c->mlx, &c->imgs);
	if (c->options.sound)
		sound_loader();
	init_gui(c);
	c->screen_size[0] = S_W;
	c->screen_size[1] = S_H;
	c->player.i = false;
	c->player.ms = MOVE_SPEED;
	c->player.e = 100;
	c->player.in = false;
	c->player.m = true;
	c->player.ir = false;
	c->player.ib = false;
	c->imgs.i_m = mlx_texture_to_image(c->mlx, c->imgs.m_t);
	mlx_resize_image(c->imgs.i_m, 250, 250);
	mlx_resize_image(c->imgs.img_player, 14, 14);
	mlx_image_to_window(c->mlx, c->imgs.img_3d, 0, 0);
	mlx_image_to_window(c->mlx, c->imgs.i_m, 20, 445);
	mlx_image_to_window(c->mlx, c->imgs.img_player, 137, 561);
	msg_write(1, -1, SUCCESS);
}

int	main(int argc, char *argv[])
{
	t_core	core;

	(void)argc;
	msg_write(1, -1, STARTING);
	core_init(&core);
	initialize_options(&core);
	item_loader(&core);
	block_loader(core.mlx);
	setup_slot_struct(core.mlx, &core.player);
	map_manager(argv[1], &core.imgs, &core.player, core.options.sprites);
	world_loader(&core);
	portal_loader();
	give_start_items(&core);
	msg_write(1, -1, MINIMAP_INIT);
	msg_write(1, -1, SUCCESS);
	mlx_hook_loader(&core);
	free_slot(core.player.s);
	free_biome();
	free_world();
	delete_image_from_struct(core.mlx, &core.imgs);
	mlx_close_window(core.mlx);
	mlx_terminate(core.mlx);
	return (0);
}
