/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   item_loader.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/31 17:17:13 by ayagmur           #+#    #+#             */
/*   Updated: 2023/07/31 17:17:14 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

static int	*shit_function(int a, int b, int c)
{
	int	*t;

	t = malloc(sizeof(int) * 3);
	t[0] = a;
	t[1] = b;
	t[2] = c;
	return (t);
}

static void	create_item(t_eit item_name, mlx_t *mlx, int s)
{
	char	*path;
	t_sit	*item;

	msg_write_multiple(1, g_messages[TRY_LOAD_ITEM], g_i_n[item_name]);
	item = malloc(sizeof(t_sit));
	item->n = item_name;
	item->a.image = 0;
	item->s = s;
	path = malloc(sizeof(char) * (ft_strlen(g_i_n[item_name]) + 18));
	pts(path, "assets/items/", g_i_n[item_name], 0);
	if (!sifp(mlx, path, &item->i))
		msg_write(2, 2, ERROR_FATAL);
	pts(path, "assets/icons/", g_i_n[item_name], 0);
	if (!sifp(mlx, path, &item->ic))
		msg_write(2, 2, ERROR_FATAL);
	free(path);
	mlx_resize_image(item->ic, 40, 40);
	mlx_image_to_window(mlx, item->i, S_W / 1.37, S_H - item->i->height);
	item->in = 0;
	item->i->instances[0].enabled = false;
	item->i->instances[0].z = 8;
	set_item(item);
}

static void	cit(t_sit *item, int *a, mlx_t *mlx, int i)
{
	char	*path;

	item->a.is_playing = false;
	item->a.depth_xy[0] = a[1];
	item->a.depth_xy[1] = a[2];
	item->a.image = malloc(sizeof(mlx_image_t) * (a[0] + 1));
	path = malloc(sizeof(char) * (ft_strlen(g_i_n[item->n]) + 19));
	while (i++ < a[0])
	{
		pts(path, "assets/items/", g_i_n[item->n], ft_itoa(i));
		if (!sifp(mlx, path, &item->a.image[i - 1]))
		{
			free(path);
			free(a);
			msg_write(2, 2, ERROR_FATAL);
		}
		mlx_image_to_window(mlx, item->a.image[i - 1], S_W / 1.4, S_H - 290);
		item->a.image[i - 1]->instances[0].enabled = false;
		item->a.image[i - 1]->instances[0].z = 8;
		free(path);
		path = malloc(sizeof(char) * (ft_strlen(g_i_n[item->n]) + 19));
	}
	free(a);
	free(path);
	item->a.image[i - 1] = 0;
}

void	item_loader(t_core *core)
{
	create_item(ITA, core->mlx, 3);
	cit(get_item(ITA), shit_function(4, 150, 0), core->mlx, 0);
	create_item(ITB, core->mlx, 1);
	cit(get_item(ITB), shit_function(3, 150, 0), core->mlx, 0);
	create_item(ITC, core->mlx, 1);
	cit(get_item(ITC), shit_function(5, 150, 0), core->mlx, 0);
	create_item(ITD, core->mlx, 1);
	cit(get_item(ITD), shit_function(5, 150, 0), core->mlx, 0);
	create_item(ITE, core->mlx, 1);
	cit(get_item(ITE), shit_function(4, 150, 0), core->mlx, 0);
	create_item(ITF, core->mlx, 2);
	cit(get_item(ITF), shit_function(6, 0, -50), core->mlx, 0);
	create_item(ITG, core->mlx, 2);
	create_item(ITH, core->mlx, 2);
	cit(get_item(ITH), shit_function(4, 0, -50), core->mlx, 0);
	create_item(ITI, core->mlx, 2);
	cit(get_item(ITI), shit_function(4, 0, -50), core->mlx, 0);
	create_item(ITJ, core->mlx, 2);
	cit(get_item(ITJ), shit_function(3, 0, 150), core->mlx, 0);
	create_item(ITK, core->mlx, 5);
	cit(get_item(ITK), shit_function(4, 0, 150), core->mlx, 0);
	create_item(ITL, core->mlx, 1);
	cit(get_item(ITL), shit_function(3, 0, 150), core->mlx, 0);
}
