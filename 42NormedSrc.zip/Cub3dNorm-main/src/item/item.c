/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   item.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ngalzand <ngalzand@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/01 11:26:30 by ngalzand          #+#    #+#             */
/*   Updated: 2023/09/01 11:26:34 by ngalzand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

void	give_item(t_core *core, t_sit *item, int slot_id, int number)
{
	t_slot	*slot;

	slot = core->player.s;
	while (slot->slot_id != slot_id)
		slot = slot->next;
	slot->item = item;
	slot->bii = mlx_image_to_window(core->mlx, item->ic, S_W / 3.35, S_H - 85);
	slot->item->ic->instances[slot->bii].z = 11;
	item->in++;
	slot->item->ic->instances[slot->bii].enabled = false;
	slot->icon_instance = mlx_image_to_window(core->mlx, item->ic, 0, 0);
	item->in++;
	slot->item->ic->instances[slot->icon_instance].enabled = false;
	slot->items_number = number;
	slot->ini = mlx_put_string(core->mlx, ft_itoa(number), 0, 0);
	slot->in = mlx_put_string(core->mlx, ft_itoa(number), 0, (S_H - 85) + 25);
	slot->in->instances[0].z = 12;
	slot->ini->instances[0].enabled = false;
	slot->in->instances[0].enabled = false;
}
