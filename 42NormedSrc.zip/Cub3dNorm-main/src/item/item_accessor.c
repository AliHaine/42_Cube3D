/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   item_accessor.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/23 23:27:24 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/23 23:27:25 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/concepts/item.h"

static t_sit			*g_items[IT9];

t_sit	*get_item(t_eit item)
{
	return (g_items[item]);
}

void	set_item(t_sit *item)
{
	g_items[item->n] = item;
}
