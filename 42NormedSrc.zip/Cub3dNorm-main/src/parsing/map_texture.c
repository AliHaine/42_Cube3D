/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_texture.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/27 14:47:37 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/27 14:47:39 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

static char	**mallocv(void)
{
	char	**v;

	v = malloc(sizeof(char *) * 3);
	v[0] = malloc(sizeof(char) * 4);
	v[1] = malloc(sizeof(char) * 4);
	v[2] = malloc(sizeof(char) * 4);
	return (v);
}

static void	set_color_value(const char *line, uint32_t *t, int b, int i)
{
	char	**v;

	v = mallocv();
	while (*line && *line == ' ')
		line++;
	while (*line)
	{
		if (*line == ',')
		{
			v[i][b] = '\0';
			i++;
			b = 0;
			line++;
		}
		if (b > 3 || i > 3)
		{
			msg_write(1, -1, FAILURE);
			break ;
		}
		v[i][b++] = *line++;
	}
	v[i][b - 1] = '\0';
	*t = (ft_a(v[0]) << 24) + (ft_a(v[1]) << 16) + (ft_a(v[2]) << 8) + 255;
	free(v);
	msg_write(1, -1, SUCCESS);
}

static void	get_color_from_map(t_file *f, uint32_t b[2], char first_key)
{
	if (!f->l || (f->l[0] != 'F' && f->l[0] != 'C') || f->l[1] != ' ')
		msg_write(2, 2, ERROR_PARSING_CHAR);
	msg_write_multiple(1, g_messages[TRY_LOAD_COLOR], f->l);
	if (f->l[0] != 'F')
	{
		first_key = 'C';
		set_color_value(f->l + 2, &b[1], 0, 0);
	}
	else
		set_color_value(f->l + 2, &b[0], 0, 0);
	get_next_line(f);
	if (!f->l || (f->l[0] != 'F' && f->l[0] != 'C') || f->l[1] != ' ')
		msg_write(2, 2, ERROR_PARSING_CHAR);
	msg_write_multiple(1, g_messages[TRY_LOAD_COLOR], f->l);
	if (f->l[0] == first_key)
		msg_write(2, 2, ERROR_KEY_ALREADY);
	if (f->l[0] != 'F')
		set_color_value(f->l + 2, &b[1], 0, 0);
	else
		set_color_value(f->l + 2, &b[0], 0, 0);
	get_next_line(f);
	while (f->l && f->l[0] == '\n')
		get_next_line(f);
}

static void	get_image_from_map(t_file *file, t_imgs *imgs, int space)
{
	int	direction;

	while (file->l)
	{
		if (file->l[0] == '\n')
			break ;
		direction = get_direction_code(file->l);
		if (direction >= 4)
			msg_write(2, 1, ERROR_PARSING_CHAR);
		if (!imgs->wall_texture[direction])
		{
			while (file->l[space] == ' ')
				space++;
			if (!stfp((file->l + space), &imgs->wall_texture[direction]))
				msg_write(2, 2, ERROR_FATAL);
			space = 3;
		}
		else
			msg_write(2, 1, ERROR_KEY_ALREADY);
		get_next_line(file);
	}
	if (is_wall_empty(imgs))
		set_default_wall_texture(imgs);
	while (file->l && file->l[0] == '\n')
		get_next_line(file);
}

void	texture_main(t_file *file, t_imgs *imgs, uint32_t bt_color[2])
{
	msg_write(1, -1, GET_MAP_CONTENT);
	get_next_line(file);
	get_image_from_map(file, imgs, 3);
	get_color_from_map(file, bt_color, 'F');
	msg_write(1, -1, SUCCESS);
}
