/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   moves.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ngalzand <ngalzand@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/11 16:48:19 by ngalzand          #+#    #+#             */
/*   Updated: 2023/05/11 16:48:26 by ngalzand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

void	move_left(t_spl *player)
{
	const float	dir_x = cosf(player->a);
	const float	dir_y = sinf(player->a);
	float		step_x;
	float		step_y;
	float		alpha;

	if (dir_y > 0)
		alpha = acos(check_overflow(dir_x));
	else
		alpha = -acos(check_overflow(dir_x));
	step_y = sinf(alpha + M_PI / 2) * player->ms;
	if (!is_block(player->pp[0], player->pp[1] - step_y))
		player->pp[1] -= step_y;
	step_x = cosf(alpha + M_PI / 2) * player->ms;
	if (!is_block(player->pp[0] - step_x, player->pp[1]))
		player->pp[0] -= step_x;
}

void	move_right(t_spl *player)
{
	const float	dir_x = cosf(player->a);
	const float	dir_y = sinf(player->a);
	float		step_x;
	float		step_y;
	float		alpha;

	if (dir_y > 0)
		alpha = acos(check_overflow(dir_x));
	else
		alpha = -acos(check_overflow(dir_x));
	step_y = sinf(alpha + M_PI / 2) * player->ms;
	if (!is_block(player->pp[0], player->pp[1] + step_y))
		player->pp[1] += step_y;
	step_x = cosf(alpha + M_PI / 2) * player->ms;
	if (!is_block(player->pp[0] + step_x, player->pp[1]))
		player->pp[0] += step_x;
}

void	move_backward(t_spl *player)
{
	float	step_x;
	float	step_y;

	step_x = cosf(player->a) * player->ms;
	step_y = sinf(player->a) * player->ms;
	if (!is_block(player->pp[0], player->pp[1] - step_y))
		player->pp[1] -= step_y;
	if (!is_block(player->pp[0] - step_x, player->pp[1]))
		player->pp[0] -= step_x;
}

void	move_forward(t_spl *player)
{
	float	step_x;
	float	step_y;

	step_x = cosf(player->a) * player->ms;
	step_y = sinf(player->a) * player->ms;
	if (!is_block(player->pp[0] + step_x, player->pp[1]))
		player->pp[0] += step_x;
	if (!is_block(player->pp[0], player->pp[1] + step_y))
		player->pp[1] += step_y;
}

void	move_rotate(t_spl *player, int direction, float speed)
{
	if (direction == 0)
	{
		player->a -= speed;
		if (player->a < 0)
			player->a += 6.28319;
	}
	else if (direction == 1)
	{
		player->a += speed;
		if (player->a > 6.28319)
			player->a -= 6.28319;
	}
}
