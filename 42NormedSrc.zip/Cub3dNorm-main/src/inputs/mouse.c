/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mouse.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/16 14:18:53 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/16 14:18:59 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

static void	mouse_left_action_zero(t_spl *player)
{
	player->ib = false;
}

static void	mouse_left_action_one(t_spl *player)
{
	if (!player_have_enough_energy(player, 20))
		return ;
	take_energy(player, 8 * get_world_active()->d);
	player->s->item->a.is_playing = true;
	player->ib = true;
}

static void	mouse_right_action(t_spl *player)
{
	if (player->s->item->n == ITJ && (get_hit_char(player)
			== get_block(BLC)->bc || get_hit_char(player)
			== get_block(BLD)->bc))
		portal_open(player);
	if (player->s->item->n == ITL && get_hit_char(player) == get_block(BLA)->bc)
		portal_close(player);
}

void	mouse(enum mouse_key m, enum action a, enum modifier_key k, void *p)
{
	t_core			*core;

	(void)m, (void)k;
	core = (t_core *)p;
	if (core->player.in)
		return ;
	if (m == 0)
	{
		if (a == 0)
			mouse_left_action_zero(&core->player);
		else
			mouse_left_action_one(&core->player);
	}
	else
		mouse_right_action(&core->player);
}
