/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mouse_cursor.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/03 19:13:15 by ayagmur           #+#    #+#             */
/*   Updated: 2023/09/03 19:13:16 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

void	resize_hook(int height, int width, void *params)
{
	t_core	*core;

	core = (t_core *)params;
	core->screen_size[0] = height;
	core->screen_size[1] = width;
}

void	mouse_cursor(mlx_t *mlx, t_spl *player, const int screen_size[2])
{
	int		x;
	int		y;
	int		diff;
	int		screen_middle_x;
	float	rotation_speed;

	if (player->in == true)
		return ;
	screen_middle_x = screen_size[0] / 2;
	if (mlx_get_time() < 0.8)
	{
		mlx_set_mouse_pos(mlx, screen_middle_x, screen_size[1] / 2);
		return ;
	}
	mlx_get_mouse_pos(mlx, &x, &y);
	mlx_set_mouse_pos(mlx, screen_middle_x, screen_size[1] / 2);
	diff = abs(screen_middle_x - x);
	rotation_speed = (float)diff / screen_middle_x * SENSIBILITY;
	if (x > screen_middle_x)
		move_rotate(player, 1, rotation_speed);
	else if (x < screen_middle_x)
		move_rotate(player, 0, rotation_speed);
}
