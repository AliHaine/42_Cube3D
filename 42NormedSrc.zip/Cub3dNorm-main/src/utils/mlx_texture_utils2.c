/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   player_utils.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/03 18:52:07 by ayagmur           #+#    #+#             */
/*   Updated: 2023/09/03 18:52:08 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

bool	stfp(char *path, mlx_texture_t **texture)
{
	msg_write_multiple(1, g_messages[TRY_LOAD_TEXTURE], path);
	if (path[ft_strlen(path) - 1] == '\n')
	{
		path[ft_strlen(path) - 1] = '\0';
		*texture = mlx_load_png(path);
	}
	else
		*texture = mlx_load_png(path);
	if (!*texture)
	{
		msg_write(2, -1, FAILURE);
		return (false);
	}
	msg_write(1, -1, SUCCESS);
	return (true);
}

bool	sifp(mlx_t *mlx, char *path, mlx_image_t **image)
{
	mlx_texture_t	*texture;

	if (!stfp(path, &texture))
		return (false);
	*image = mlx_texture_to_image(mlx, texture);
	return (true);
}

void	delete_image_from_struct(mlx_t *mlx, t_imgs *imgs)
{
	mlx_delete_image(mlx, imgs->img_3d);
	mlx_delete_image(mlx, imgs->img_player);
	mlx_delete_image(mlx, imgs->i_m);
	mlx_delete_image(mlx, imgs->crosshair);
}

uint32_t	g_rgb(int r, int g, int b, int a)
{
	return ((r << 24) | (g << 16) | (b << 8) | a);
}

uint32_t	get_pixel(mlx_texture_t *texture, int x, int y)
{
	uint32_t					color;
	int							step;

	step = (x + y * texture->width) * 4;
	color = (texture->pixels[step] << 24)
		+ (texture->pixels[step + 1] << 16)
		+ (texture->pixels[step + 2] << 8)
		+ (texture->pixels[step + 3]);
	return (color);
}
