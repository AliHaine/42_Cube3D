/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   crafting_utils.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ngalzand <ngalzand@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/02 15:32:02 by ngalzand          #+#    #+#             */
/*   Updated: 2023/10/02 15:38:11 by ngalzand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

bool	lighter_check(t_slot *craft_table[10])
{
	int		ij[2];
	int		ric[2];

	ric[0] = 0;
	ric[1] = 0;
	ij[0] = -1;
	while (++ij[0] < 3)
	{
		ij[1] = -1;
		while (++ij[1] < 3)
		{
			if (craft_table[ij[0] * 3 + ij[1]]->item->n == ITI)
				ric[0]++;
			else if (craft_table[ij[0] * 3 + ij[1]]->item->n == ITH)
				ric[1]++;
			else if (craft_table[ij[0] * 3 + ij[1]]->item->n != ITA)
				return (false);
		}
	}
	if (ric[0] == 1 && ric[1] == 1)
		return (true);
	return (false);
}
