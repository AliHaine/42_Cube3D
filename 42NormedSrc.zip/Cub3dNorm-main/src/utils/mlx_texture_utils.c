/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   player_utils.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/03 18:52:07 by ayagmur           #+#    #+#             */
/*   Updated: 2023/09/03 18:52:08 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

void	dpi1(mlx_image_t *img, int e, int x, int y)
{
	uint32_t	full_color;

	full_color = g_rgb(192, 19, 186, 255);
	while (e-- >= 0)
		mlx_put_pixel(img, x++, y, full_color);
}

void	dpi2(mlx_image_t *img, int e, int x, int y)
{
	uint32_t	empty_color;

	empty_color = g_rgb(100, 80, 190, 255);
	while (e-- >= 0)
		mlx_put_pixel(img, x++, y, empty_color);
}

static void	rotate_util(mlx_image_t *i, mlx_texture_t *txt, int s[2], int xy[2])
{
	int	dst_offset;
	int	src_offset;

	if (s[0] >= 0 && (uint32_t)s[0] < txt->width
		&& s[1] >= 0 && (uint32_t)s[1] < txt->height)
	{
		dst_offset = (s[1] * (int)txt->width + s[0]) * 4;
		src_offset = (xy[1] * (int)txt->width + xy[0]) * 4;
		i->pixels[dst_offset] = txt->pixels[src_offset];
		i->pixels[dst_offset + 1] = txt->pixels[src_offset + 1];
		i->pixels[dst_offset + 2] = txt->pixels[src_offset + 2];
		i->pixels[dst_offset + 3] = txt->pixels[src_offset + 3];
	}
}

mlx_image_t	*rotate_image(mlx_t *mlx, mlx_texture_t *texture, float angle)
{
	const float	cost = cosf(angle);
	const float	sint = sinf(angle);
	mlx_image_t	*new_img;
	int			xy[2];
	int			src_xy[2];

	new_img = mlx_new_image(mlx, (int)texture->width, (int)texture->height);
	xy[1] = -1;
	while (++xy[1] < (int)texture->height)
	{
		xy[0] = -1;
		while (++xy[0] < (int)texture->width)
		{
			src_xy[0] = (int)(((float)xy[0] - (float)texture->width / 2)
					* cost - ((float)xy[1] - (float)texture->height / 2)
					* sint + ((float)texture->width / 2));
			src_xy[1] = (int)(((float)xy[0] - (float)texture->width / 2)
					* sint + ((float)xy[1] - (float)texture->height / 2)
					* cost + ((float)texture->height / 2));
			if (src_xy[0] >= 0 && (uint32_t)src_xy[0] < texture->width
				&& src_xy[1] >= 0 && (uint32_t)src_xy[1] < texture->height)
				rotate_util(new_img, texture, src_xy, xy);
		}
	}
	return (new_img);
}
