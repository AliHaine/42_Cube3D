/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   player_utils.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/03 18:52:07 by ayagmur           #+#    #+#             */
/*   Updated: 2023/09/03 18:52:08 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

void	set_player(int x, int y, t_spl *player, float angle)
{
	t_swo	*world;

	world = get_world_active();
	player->pp[0] = ((x + world->y) * 64) + 32;
	player->pp[1] = ((y + world->h) * 64) + 32;
	player->pc[0] = x + world->y;
	player->pc[1] = y + world->h;
	player->a = angle;
}

char	get_hit_char(t_spl *player)
{
	int		x;
	int		y;
	t_swo	*w;

	w = get_world_active();
	x = player->pp[0] + cosf(player->a) * 55;
	y = player->pp[1] + sinf(player->a) * 55;
	return (w->w[gcfp(x / 64, y / 64)][(y / 64) % w->h][(x / 64) % w->y]);
}
