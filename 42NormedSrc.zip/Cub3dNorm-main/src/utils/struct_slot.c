/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   struct_slot.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/07 20:38:24 by ayagmur           #+#    #+#             */
/*   Updated: 2023/09/07 20:38:26 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

static t_slot	*add_new_noed(mlx_t *mlx, short v, t_slot *c, t_sit *h)
{
	c->prev = malloc(sizeof(t_slot));
	c->prev->icon_instance = -1;
	c->prev->bii = -1;
	c->prev->slot_id = v;
	c->prev->item = h;
	c->items_number = 1;
	c->ini = mlx_put_string(mlx, "1", 0, 0);
	c->in = mlx_put_string(mlx, "1", 0, 0);
	c->in->instances[0].y = (S_H - 85) + 25;
	c->ini->instances->enabled = false;
	c->in->instances->enabled = false;
	c->ini->instances[0].z = 11;
	c->bar_mutex = false;
	c->prev->next = c;
	return (c->prev);
}

static t_slot	*add_first_noed(mlx_t *mlx, t_sit *hand_item)
{
	t_slot	*first;

	first = malloc(sizeof(t_slot));
	first->slot_id = 47;
	first->icon_instance = -1;
	first->bii = -1;
	first->item = hand_item;
	first->items_number = 1;
	first->ini = mlx_put_string(mlx, "1", 0, 0);
	first->in = mlx_put_string(mlx, "1", 0, 0);
	first->in->instances[0].y = (S_H - 85) + 25;
	first->ini->instances->enabled = false;
	first->in->instances->enabled = false;
	first->bar_mutex = false;
	first->ini->instances[0].z = 11;
	first->next = 0;
	return (first);
}

void	free_slot(t_slot *slot)
{
	t_slot	*current;

	while (slot->prev)
		slot = slot->prev;
	current = slot;
	while (current)
	{
		slot = slot->next;
		free(current);
		current = slot;
	}
}

void	setup_slot_struct(mlx_t *mlx, t_spl *player)
{
	int	i;

	i = 47;
	player->s = add_first_noed(mlx, get_item(ITA));
	while (i-- > 0)
		player->s = add_new_noed(mlx, i, player->s, get_item(ITA));
	player->s = player->s->next;
	player->s->prev = 0;
}

t_slot	*get_first_slot(t_slot *slot)
{
	t_slot	*copy;

	copy = slot;
	while (copy->slot_id != 1)
		copy = copy->prev;
	return (copy);
}
