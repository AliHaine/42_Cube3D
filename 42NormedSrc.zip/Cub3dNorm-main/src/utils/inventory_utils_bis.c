/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   inventory_utils_bis.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ngalzand <ngalzand@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/01 11:27:46 by ngalzand          #+#    #+#             */
/*   Updated: 2023/09/01 11:27:47 by ngalzand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

void	reset_slot(t_slot *slot)
{
	if (slot->icon_instance != (uint32_t)-1)
		slot->item->ic->instances[slot->icon_instance].enabled = false;
	if (slot->bii != (uint32_t)-1)
		slot->item->ic->instances[slot->bii].enabled = false;
	slot->item = get_item(ITA);
	slot->items_number = 1;
	slot->ini->instances[0].enabled = false;
	slot->in->instances[0].enabled = false;
	slot->icon_instance = -1;
	slot->bii = -1;
	slot->bii = -1;
}

void	change_item_number(t_core *core, t_slot *src, short n)
{
	if (src->icon_instance == (uint32_t)-1)
		return ;
	mlx_delete_image(core->mlx, src->ini);
	mlx_delete_image(core->mlx, src->in);
	src->items_number = n;
	src->ini = mlx_put_string
		(core->mlx, ft_itoa(src->items_number),
			src->item->ic->instances[src->icon_instance].x + 23,
			src->item->ic->instances[src->icon_instance].y + 25);
	src->in = mlx_put_string
		(core->mlx, ft_itoa(src->items_number),
			src->item->ic->instances[src->bii].x + 23,
			src->item->ic->instances[src->bii].y + 25);
	if (src->slot_id > 9)
		src->in->instances[0].enabled = false;
}

void	give_start_items(t_core *core)
{
	give_item(core, get_item(ITB), 2, 32);
	give_item(core, get_item(ITB), 32, 52);
	give_item(core, get_item(ITC), 5, 1);
	give_item(core, get_item(ITE), 1, 1);
	give_item(core, get_item(ITD), 8, 1);
	give_item(core, get_item(ITF), 14, 3);
	give_item(core, get_item(ITG), 16, 2);
	give_item(core, get_item(ITH), 22, 1);
	give_item(core, get_item(ITI), 36, 1);
	give_item(core, get_item(ITK), 12, 1);
	give_item(core, get_item(ITL), 9, 1);
}
