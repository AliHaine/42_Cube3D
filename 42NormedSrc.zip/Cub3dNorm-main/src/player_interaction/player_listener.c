/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   player_listener.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/20 01:08:55 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/20 01:08:59 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

static bool	energy_listener(t_spl *player, t_sdi difficulty)
{
	if (is_player_running(player))
	{
		if (!player_have_energy(player->e))
			player->ms = MOVE_SPEED;
		return (take_energy(player, 1 + difficulty));
	}
	else
		return (add_energy(player, 1));
}

void	player_listener(void *params)
{
	t_core	*core;
	t_swo	*world;

	core = (t_core *) params;
	world = get_world_active();
	if (energy_listener(&core->player, world->d))
		draw_energy_bar(core->imgs.engbar, core->player.e, 3, 1);
	if (core->player.ib)
		player_build(&core->player, core->options);
	if (core->player.im)
	{
		if (core->player.ir)
		{
			play_sound_alt(get_sound(SOF), false, false);
			play_sound_alt(get_sound(SOG), true, false);
		}
		else
			play_sound_alt(get_sound(SOF), true, false);
	}
	else
	{
		play_sound_alt(get_sound(SOG), false, false);
		play_sound_alt(get_sound(SOF), false, false);
	}
	portal_listener(&core->player, world);
}
