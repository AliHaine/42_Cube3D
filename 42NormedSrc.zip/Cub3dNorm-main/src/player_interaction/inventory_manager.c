/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   inventory_manager.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ngalzand <ngalzand@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/01 11:25:25 by ngalzand          #+#    #+#             */
/*   Updated: 2023/09/01 11:25:29 by ngalzand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

void	stack_item(t_core *core, t_slot *src, t_slot *dst, bool *holding)
{
	const int	n = src->items_number + dst->items_number;

	if (src->items_number + dst->items_number > 64)
	{
		change_item_number(core, dst, 64);
		display_item(dst);
		change_item_number(core, src, n % 64);
		display_item(src);
		*holding = true;
		src->bar_mutex = true;
		src->ini->instances[0].z = 14;
		src->item->ic->instances[src->icon_instance].z = 13;
		return ;
	}
	change_item_number(core, dst, n);
	dst->ini->instances[0].z = 12;
	reset_slot(src);
	display_item(src);
}

static void	apply_slot(t_core *core, t_slot *slot, bool *holding, int s)
{
	slot->ini->instances[0].z = 12;
	slot->bar_mutex = false;
	*holding = false;
	if (s == -1 || !slot || slot->slot_id == get_slot(core, s)->slot_id
		|| get_slot(core, s)->slot_id == 46)
		display_item(slot);
	else if (slot->item->n != ITA && get_slot(core, s)->item->n == ITA)
		set_on_void_slot(core, slot, s);
	else if (slot->item->n == get_slot(core, s)->item->n)
		stack_item(core, slot, get_slot(core, s), holding);
	else if (slot->item->n != ITA && get_slot(core, s)->item->n != ITA)
	{
		reverse_attributes(slot, get_slot(core, s));
		display_item(get_slot(core, s));
		get_slot(core, s)->bar_mutex = false;
		slot->in->instances[0].enabled = false;
		slot->item->ic->instances[slot->bii].enabled = false;
		slot->bar_mutex = true;
		slot->ini->instances[0].z = 14;
		slot->item->ic->instances[slot->icon_instance].z = 13;
		*holding = true;
	}
}

void	give_one_to(t_core *core, t_slot *src, t_slot *dst)
{
	if (dst->slot_id == 47)
		return ;
	if (src->item->n == dst->item->n
		&& src->items_number > 1 && dst->items_number < 64)
	{
		change_item_number(core, src, src->items_number - 1);
		src->ini->instances[0].z = 14;
		change_item_number(core, dst, dst->items_number + 1);
		dst->ini->instances[0].z = 12;
	}
	else if (dst->item->n == ITA && src->items_number > 1 && dst->slot_id != 46)
	{
		change_item_number(core, src, src->items_number - 1);
		give_item(core, get_item(src->item->n), dst->slot_id, 1);
		display_item(dst);
	}
}

static void	select_action(t_core *core, t_slot **s, bool *holding)
{
	int	x;
	int	y;

	mlx_get_mouse_pos(core->mlx, &x, &y);
	if (mlx_is_mouse_down(core->mlx, MLX_MOUSE_BUTTON_RIGHT))
	{
		if (s[0] && s[0]->item && s[0]->item->n != ITA)
			give_one_to(core, *s, get_slot(core, dps(core, x, y)));
	}
	else if (*holding == false)
	{
		if (dps(core, x, y) == 46)
			craft(core);
		*s = get_slot(core, dps(core, x, y));
		if (!s[0] || s[0]->item->n == ITA)
			return ;
		*holding = true;
		s[0]->bar_mutex = true;
		s[0]->in->instances[0].enabled = false;
		s[0]->item->ic->instances[s[0]->icon_instance].z = 13;
		s[0]->ini->instances[0].z = 14;
		s[0]->item->ic->instances[s[0]->bii].enabled = false;
	}
	else if (*holding == true)
		apply_slot(core, *s, holding, dps(core, x, y));
}

void	inventory_hook(void *params)
{
	t_core			*core;
	static t_slot	*s = 0;
	static bool		holding = false;

	core = (t_core *)params;
	core->player.it = &holding;
	if (!core->player.in)
	{
		holding = false;
		if (s && s->slot_id <= 9 && s->item->n != ITA)
		{
			s->in->instances[0].enabled = true;
			s->item->ic->instances[s->bii].enabled = true;
		}
		return ;
	}
	if (mlx_is_mouse_down(core->mlx, MLX_MOUSE_BUTTON_LEFT)
		|| mlx_is_mouse_down(core->mlx, MLX_MOUSE_BUTTON_RIGHT))
	{
		select_action(core, &s, &holding);
		usleep(100000);
	}
	if (s != 0 && holding == true && s->item->n != ITA)
		follow_cursor(core, s);
	crafting_engine(core);
}
