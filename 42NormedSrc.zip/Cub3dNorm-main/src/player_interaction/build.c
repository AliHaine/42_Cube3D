/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   build.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/03 18:54:38 by ayagmur           #+#    #+#             */
/*   Updated: 2023/09/03 18:54:39 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

void	set_char_at_forward(char c, t_spl *player)
{
	int		x;
	int		y;
	t_swo	*w;

	w = get_world_active();
	x = player->pp[0] + cosf(player->a) * 55;
	y = player->pp[1] + sinf(player->a) * 55;
	w->w[gcfp(x / 64, y / 64)][(y / 64) % w->h][(x / 64) % w->y] = c;
}

static void	process_build(t_spl *player, t_sbl *block, t_sit *item)
{
	static int	i = 0;

	if (i <= 0)
	{
		play_sound_alt(get_sound(SOH), true, true);
		i = block->s;
	}
	i -= item->s;
	if (i <= 0)
	{
		play_sound_alt(get_sound(SOH), false, false);
		play_sound(get_sound(SOI));
		set_char_at_forward('0', player);
		player->ib = false;
	}
}

void	player_build(t_spl *player, t_options options)
{
	char	c;

	c = get_hit_char(player);
	if (c == '0' || options.break_blocks != true || player->in)
		return ;
	if (c == '1')
	{
		set_char_at_forward('0', player);
		return ;
	}
	player->s->item->a.is_playing = true;
	process_build(player, gbfc(c), player->s->item);
}
