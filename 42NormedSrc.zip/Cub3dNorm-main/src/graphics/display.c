/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ngalzand <ngalzand@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/11 16:47:51 by ngalzand          #+#    #+#             */
/*   Updated: 2023/05/11 16:47:54 by ngalzand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/includes.h"

static void	set_imgs_z(t_imgs *imgs)
{
	imgs->img_3d->instances[0].z = 1;
	imgs->i_m->instances[0].z = 3;
	imgs->img_player->instances[0].z = 4;
	imgs->crosshair->instances[0].z = 5;
	imgs->invbar->instances[0].z = 6;
	imgs->invbar_selector->instances[0].z = 7;
	imgs->engbar->instances[0].z = 9;
}

static void	display_icon_in_invbar(t_slot *slot)
{
	t_slot				*iterator;
	static const int	div = S_W / 3.35;

	iterator = slot;
	while (iterator->prev)
		iterator = iterator->prev;
	while (iterator->next && iterator->next->slot_id < 11)
	{
		if (iterator->item->n != ITA && !iterator->bar_mutex)
		{
			iterator->in->instances[0].x
				= (div + ((iterator->slot_id - 1) * 61)) + 23;
			iterator->in->instances[0].enabled = true;
			iterator->item->ic->instances[iterator->bii].x
				= div + ((iterator->slot_id - 1) * 61);
			iterator->item->ic->instances[iterator->bii].enabled
				= true;
		}
		else
			iterator->in->instances[0].enabled = false;
		iterator = iterator->next;
	}
}

static void	display_item_in_hand(t_spl *player)
{
	t_slot	*tempo;

	tempo = get_first_slot(player->s);
	while (tempo->next)
	{
		tempo->item->i->instances[0].enabled = 0;
		tempo = tempo->next;
	}
	player->s->item->i->instances[0].enabled = 1;
}

void	display(void *params)
{
	t_core	*core;

	core = (t_core *) params;
	animation_listener();
	display_item_in_hand(&core->player);
	display_icon_in_invbar(get_first_slot(core->player.s));
	mlx_delete_image(core->mlx, core->imgs.i_m);
	core->imgs.i_m = mlx_texture_to_image
		(core->mlx, core->imgs.m_t);
	raycasting(&core->player, &core->imgs, &core->options);
	minimap_drawing(&core->imgs, core->player.pp, get_world_active());
	mlx_delete_image(core->mlx, core->imgs.img_player);
	core->imgs.img_player = rotate_image(core->mlx,
			core->imgs.img_player_texture, core->player.a + (PI / 2));
	mlx_resize_image(core->imgs.i_m, 250, 250);
	mlx_image_to_window(core->mlx, core->imgs.i_m, 20, 445);
	mlx_image_to_window(core->mlx, core->imgs.img_player, 132, 556);
	set_imgs_z(&core->imgs);
}
