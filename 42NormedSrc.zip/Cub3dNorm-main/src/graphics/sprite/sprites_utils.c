/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sprites_utils.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ngalzand <ngalzand@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/02 12:49:02 by ngalzand          #+#    #+#             */
/*   Updated: 2023/10/02 12:49:07 by ngalzand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/includes.h"

void	init_sprite_vars(t_ssp *sp, t_spl *player, mlx_texture_t *img)
{
	sp->f = sp->d / FOG_DISTANCE;
	if (sp->f > 1)
		return ;
	sp->v.a[2] = S_H / 2.f;
	sp->v.a[0] = (sp->sa[0] - player->pp[0]);
	sp->v.a[1] = (sp->sa[1] - player->pp[1]);
	sp->v.t[0] = sp->v.a[1] * -player->cos + sp->v.a[0] * player->sin;
	sp->v.t[1] = sp->v.a[0] * player->cos + sp->v.a[1] * player->sin;
	sp->v.a[0] = sp->v.t[0];
	sp->v.a[1] = sp->v.t[1];
	sp->v.a[0] = (sp->v.a[0] * -1280 / sp->v.a[1]) + (S_W / 2.f);
	sp->v.a[1] = (sp->v.a[2] * 70 / sp->v.a[1]) + (S_H / 2.f);
	sp->v.s[0] = (int)((float)(img->width * sp->s) / sp->v.t[1]);
	sp->v.s[1] = (int)((float)(img->height * sp->s) / sp->v.t[1]);
	if (sp->v.s[0] < 0)
		sp->v.s[0] = 0;
	if (sp->v.s[1] < 0)
		sp->v.s[1] = 0;
	sp->v.p[0] = (float)img->width;
	sp->v.o[0] = (float)img->width / (float)sp->v.s[0];
	sp->v.o[1] = (float)img->height / (float)sp->v.s[1];
	sp->v.x = 0;
}

void	realloc_sprites(t_ssp ***sprites, int len)
{
	t_ssp		**new_tab;
	int			s;

	s = -1;
	new_tab = (t_ssp **)malloc(sizeof(t_ssp *) * (len + 2));
	while (++s < len)
		new_tab[s] = (*sprites)[s];
	new_tab[s] = (t_ssp *)malloc(sizeof(t_ssp));
	new_tab[s + 1] = NULL;
	if (*sprites)
	{
		free(*sprites);
		*sprites = NULL;
	}
	*sprites = new_tab;
}

void	reload_sprite_pos(t_swo *world)
{
	int	chunk;
	int	s;

	chunk = -1;
	while (++chunk < 9)
	{
		s = -1;
		while (world->z[chunk][++s])
		{
			world->z[chunk][s]->c[0] = (int)(world->z
				[chunk][s]->x + (world->y * (chunk % 3)));
			world->z[chunk][s]->c[1] = (int)(world->z
				[chunk][s]->y + (world->h * (int)
						lround(((float)chunk - 1.f) / 3.f)));
			world->z[chunk][s]->sa[0] = ((float)
					(world->z[chunk][s]->c[0]) + 0.5f) * 64;
			world->z[chunk][s]->sa[1] = ((float)
					(world->z[chunk][s]->c[1]) + 0.5f) * 64;
		}
	}
}
