/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   move_multiple_sprites.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ngalzand <ngalzand@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/02 14:59:02 by ngalzand          #+#    #+#             */
/*   Updated: 2023/10/02 14:59:04 by ngalzand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/includes.h"

/* Forced to put this atrocity for the norm */

static void	move_multiple_sprites_quater(t_swo *world)
{
	t_ssp	**chunk1;
	t_ssp	**chunk2;
	t_ssp	**chunk3;

	chunk1 = world->z[2];
	chunk2 = world->z[5];
	chunk3 = world->z[8];
	world->z[2] = world->z[1];
	world->z[5] = world->z[4];
	world->z[8] = world->z[7];
	world->z[1] = world->z[0];
	world->z[4] = world->z[3];
	world->z[7] = world->z[6];
	world->z[0] = chunk1;
	world->z[3] = chunk2;
	world->z[6] = chunk3;
}

static void	move_multiple_sprites_ter(t_swo *world)
{
	t_ssp	**chunk1;
	t_ssp	**chunk2;
	t_ssp	**chunk3;

	chunk1 = world->z[0];
	chunk2 = world->z[1];
	chunk3 = world->z[2];
	world->z[0] = world->z[3];
	world->z[1] = world->z[4];
	world->z[2] = world->z[5];
	world->z[3] = world->z[6];
	world->z[4] = world->z[7];
	world->z[5] = world->z[8];
	world->z[6] = chunk1;
	world->z[7] = chunk2;
	world->z[8] = chunk3;
}

static void	move_multiple_sprites_bis(t_swo *world, int dir)
{
	t_ssp	**chunk1;
	t_ssp	**chunk2;
	t_ssp	**chunk3;

	if (dir == 5)
	{
		chunk1 = world->z[0];
		chunk2 = world->z[3];
		chunk3 = world->z[6];
		world->z[0] = world->z[1];
		world->z[3] = world->z[4];
		world->z[6] = world->z[7];
		world->z[1] = world->z[2];
		world->z[4] = world->z[5];
		world->z[7] = world->z[8];
		world->z[2] = chunk1;
		world->z[5] = chunk2;
		world->z[8] = chunk3;
	}
	else if (dir == 7)
		move_multiple_sprites_ter(world);
	else if (dir == 3)
		move_multiple_sprites_quater(world);
}

void	move_multiple_sprites(t_swo *world, int dir)
{
	t_ssp	**chunk1;
	t_ssp	**chunk2;
	t_ssp	**chunk3;

	if (dir == 1)
	{
		chunk1 = world->z[6];
		chunk2 = world->z[7];
		chunk3 = world->z[8];
		world->z[6] = world->z[3];
		world->z[7] = world->z[4];
		world->z[8] = world->z[5];
		world->z[3] = world->z[0];
		world->z[4] = world->z[1];
		world->z[5] = world->z[2];
		world->z[0] = chunk1;
		world->z[1] = chunk2;
		world->z[2] = chunk3;
	}
	else
		move_multiple_sprites_bis(world, dir);
}
