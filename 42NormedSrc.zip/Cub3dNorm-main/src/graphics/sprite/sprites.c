/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sprites.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ngalzand <ngalzand@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/02 12:48:42 by ngalzand          #+#    #+#             */
/*   Updated: 2023/10/02 12:48:51 by ngalzand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/includes.h"

static void	dsp(t_ssp *sp, mlx_image_t *i3, mlx_texture_t *i, const float *d)
{
	uint32_t	color;
	int			value;

	color = 0;
	value = ((int)sp->v.p[1] * (int)i->width
			- (int)sp->v.p[0]) * 4;
	if (value > 0 && value < (int)((i->height * i->width) * 4) - 4)
		color = (i->pixels[value] << 24) | (i->pixels[value + 1]
				<< 16) | (i->pixels[value + 2] << 8) | i->pixels[value + 3];
	if (color != 0 && d[sp->v.c[0]] > sp->d)
	{
		color = apply_fog(color, sp->f);
		mlx_put_pixel(i3, sp->v.c[0], sp->v.c[1], color);
	}
}

static void	ds(t_ssp *sp, mlx_image_t *i3, mlx_texture_t *i, const float *d)
{
	while (sp->v.x++ < sp->v.s[0])
	{
		sp->v.c[0] = (int)(sp->v.a[0] - (float)sp->v.x) + (sp->v.s[0] / 2);
		if (sp->v.c[0] >= S_W || sp->v.c[0] < 0)
		{
			sp->v.p[0] -= sp->v.o[0];
			continue ;
		}
		sp->v.p[1] = (float)i->height;
		sp->v.y = 0;
		while (sp->v.y++ < sp->v.s[1] && ((int)sp->v.p[1] * i->width
				- (int)sp->v.p[0] >= 0))
		{
			sp->v.c[1] = (int)(sp->v.a[1] - (float)sp->v.y);
			if (sp->v.c[1] >= 0 && sp->v.c[1] < S_H)
			{
				dsp(sp, i3, i, d);
			}
			sp->v.p[1] -= sp->v.o[1];
		}
		sp->v.p[0] -= sp->v.o[0];
	}
}

bool	sprite_are_sorted(t_ssp **sprite)
{
	int	i;
	int	j;

	i = -1;
	while (sprite[++i])
	{
		j = i;
		while (sprite[++j])
		{
			if (sprite[i]->d < sprite[j]->d)
				return (false);
		}
	}
	return (true);
}

void	sort_sprites(t_spl *player, t_ssp ***sprites)
{
	int			ij[2];
	t_ssp		*tmp;
	float		dxy[2];

	ij[0] = -1;
	while ((*sprites)[++ij[0]])
	{
		dxy[0] = player->pp[0] - (*sprites)[ij[0]]->sa[0];
		dxy[1] = player->pp[1] - (*sprites)[ij[0]]->sa[1];
		(*sprites)[ij[0]]->d = sqrtf(dxy[0] * dxy[0] + dxy[1] * dxy[1]);
	}
	while (!sprite_are_sorted((*sprites)))
	{
		ij[1] = -1;
		while (++ij[1] < ij[0] - 1)
		{
			if ((*sprites)[ij[1]]->d < (*sprites)[ij[1] + 1]->d)
			{
				tmp = (*sprites)[ij[1]];
				(*sprites)[ij[1]] = (*sprites)[ij[1] + 1];
				(*sprites)[ij[1] + 1] = tmp;
			}
		}
	}
}

void	draw_sprites(t_spl *player, t_imgs *imgs, const float *dists)
{
	t_swo	*world;
	int		chunk;
	int		s;

	chunk = -1;
	world = get_world_active();
	if (!world->z || !world->z[0])
		return ;
	player->cos = cosf(player->a);
	player->sin = sinf(player->a);
	while (++chunk < 9)
	{
		s = -1;
		sort_sprites(player, &world->z[chunk]);
		while (world->z[chunk][++s])
		{
			init_sprite_vars(world->z[chunk][s], player, world->z[chunk][s]->t);
			if (world->z[chunk][s]->f > 1 || world->z[chunk][s]->d < 15)
				continue ;
			ds(world->z[chunk][s], imgs->img_3d, world->z[chunk][s]->t, dists);
		}
	}
}
