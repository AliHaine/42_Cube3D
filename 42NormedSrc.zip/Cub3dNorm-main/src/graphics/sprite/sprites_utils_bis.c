/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sprites_utils_bis.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ngalzand <ngalzand@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/02 12:49:11 by ngalzand          #+#    #+#             */
/*   Updated: 2023/10/02 12:49:14 by ngalzand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/includes.h"

static void	select_sprite_ter(t_ssp *sp, char c)
{
	if (c == ';')
	{
		if (!stfp("assets/sprites/fire_coral.png", &sp->t))
			msg_write(2, 2, ERROR_FATAL);
		sp->s = 312 + r(412, 2);
	}
	else if (c == '?')
	{
		if (!stfp("assets/sprites/warped_fungus.png", &sp->t))
			msg_write(2, 2, ERROR_FATAL);
		sp->s = 196;
	}
	else if (c == '/')
	{
		if (!stfp("assets/sprites/wither_rose.png", &sp->t))
			msg_write(2, 2, ERROR_FATAL);
		sp->s = 196;
	}
}

static bool	select_sprite_bis(t_ssp *sp, char c)
{
	if (c == '^')
	{
		if (!stfp("assets/sprites/carrots_stage1.png", &sp->t))
			msg_write(2, 2, ERROR_FATAL);
		sp->s = 312 + r(412, 2);
		return (true);
	}
	else if (c == ':')
	{
		if (!stfp("assets/sprites/crimson_fungus.png", &sp->t))
			msg_write(2, 2, ERROR_FATAL);
		sp->s = 196;
		return (true);
	}
	return (false);
}

void	select_sprite(t_ssp *sp, char c)
{
	if (c == '>')
	{
		if (!stfp("assets/sprites/pink_tulip.png", &sp->t))
			msg_write(2, 2, ERROR_FATAL);
		sp->s = 228;
	}
	else if (c == '<')
	{
		if (!stfp("assets/sprites/poppy.png", &sp->t))
			msg_write(2, 2, ERROR_FATAL);
		sp->s = 228;
	}
	else if (c == 'v')
	{
		if (!stfp("assets/sprites/brown_mushroom.png", &sp->t))
			msg_write(2, 2, ERROR_FATAL);
		sp->s = 196;
	}
	else if (!select_sprite_bis(sp, c))
		select_sprite_ter(sp, c);
}

void	free_all_sprites(t_swo *world)
{
	int	s;
	int	chunk;

	chunk = -1;
	if (!world->z)
		return ;
	while (++chunk < 9)
	{
		s = -1;
		if (!world->z[chunk])
			continue ;
		while (world->z[chunk][++s])
			free(world->z[chunk][s]);
		free(world->z[chunk]);
	}
	free(world->z);
}
