/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sprites_manager.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ngalzand <ngalzand@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/02 12:48:57 by ngalzand          #+#    #+#             */
/*   Updated: 2023/10/02 12:48:59 by ngalzand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/includes.h"

char	get_rand_sprite_char(t_swo *world)
{
	static const char	tab_default[] = {'>', '<', '^', 'v'};
	static const char	tab_nether[] = {':', ';', '?', '/'};

	if (world->n == WOA)
		return (tab_default[r(4, 1)]);
	else
		return (tab_nether[r(4, 1)]);
}

void	sprites_place(t_swo *world, int chunk)
{
	if (!world->z)
		return ;
	move_multiple_sprites(world, chunk);
	reload_sprite_pos(world);
}

void	add_sprite(t_swo *w, int c, char ch, int xy[2])
{
	int	l;

	l = 0;
	while (w->z[c] != NULL && w->z[c][l])
		l++;
	if (w->z[c] == NULL)
	{
		w->z[c] = (t_ssp **)malloc(sizeof(t_ssp *) * 2);
		w->z[c][0] = (t_ssp *)malloc(sizeof(t_ssp));
		w->z[c][1] = NULL;
	}
	else
		realloc_sprites(&w->z[c], l);
	w->z[c][l]->x = xy[0];
	w->z[c][l]->y = xy[1];
	w->z[c][l]->c[0] = (int)(w->z
		[c][l]->x + (w->y * (c % 3)));
	w->z[c][l]->c[1] = (int)(w->z
		[c][l]->y + (w->h * lround(((float)c - 1.f) / 3.f)));
	w->z[c][l]->sa[0] = ((float)(w->z[c][l]->c[0])
			+ ((r(9, 1) / 10) + 0.2f)) * 64;
	w->z[c][l]->sa[1] = ((float)(w->z[c][l]->c[1])
			+ ((r(9, 1) / 10) + 0.2f)) * 64;
	select_sprite(w->z[c][l], ch);
}

void	sprites_generator(t_swo *world)
{
	int	chunk;
	int	xy[2];

	chunk = -1;
	if ((world->n != WOA
			&& world->n != WOB) || !world->z)
	{
		world->z = NULL;
		return ;
	}
	while (++chunk < 9)
	{
		xy[1] = -1;
		while (++xy[1] < world->h)
		{
			xy[0] = -1;
			while (++xy[0] < world->y)
				if (!r(5, 1))
					add_sprite(world, chunk, get_rand_sprite_char
						(world), xy);
		}
	}
	reload_sprite_pos(world);
}
