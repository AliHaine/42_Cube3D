/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ceil_and_floor.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ngalzand <ngalzand@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/02 15:00:13 by ngalzand          #+#    #+#             */
/*   Updated: 2023/10/02 15:00:16 by ngalzand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/includes.h"

static bool	pc(t_imgs *imgs, t_dda *d, t_sco *tcd, int f)
{
	if (f > 1)
	{
		mlx_put_pixel(imgs->img_3d, d->ray, tcd->i++,
			(0 << 24) | (0 << 16) | (0 << 8) | 255);
		return (false);
	}
	return (true);
}

void	ceil_drawing(t_imgs *imgs, t_dda *dda, t_sco *tcd, t_spl *player)
{
	const float	d = (((S_H / 2.f) * 64.f) / (1 + (S_H / 2.f) - tcd->i)
			/ cosf(dda->ca - player->a));
	const float	fog_strength = d / FOG_DISTANCE;
	t_swo		*world;
	int			value;
	uint32_t	color;

	world = get_world_active();
	if (!pc(imgs, dda, tcd, fog_strength))
		return ;
	value = (((int)(player->pp[0] + dda->cos
					* d) % 64)
			+ ((int)(player->pp[1] + dda->sin
					* d) % 64) * 64) * 4;
	if (value < 0)
		value = -value;
	color = g_rgb(world->p->pixels[value],
			world->p->pixels[value + 1],
			world->p->pixels[value + 2],
			world->p->pixels[value + 3]);
	color = apply_fog(color, fog_strength);
	mlx_put_pixel(imgs->img_3d, dda->ray, tcd->i++, color);
}

void	floor_drawing(t_imgs *imgs, t_dda *dda, t_sco *tcd, t_spl *player)
{
	const float	d = (((S_H / 2.f) * 64.f) / (tcd->i - (S_H / 2.f) + 1.f)
			/ cosf(dda->ca - player->a));
	const float	fog_strength = d / FOG_DISTANCE;
	t_swo		*world;
	int			value;
	uint32_t	color;

	world = get_world_active();
	if (!pc(imgs, dda, tcd, fog_strength))
		return ;
	value = (((int)(player->pp[0] + dda->cos
					* d) % 64)
			+ ((int)(player->pp[1] + dda->sin
					* d) % 64) * 64) * 4;
	if (value < 0)
		value = -value;
	color = g_rgb(world->f->pixels[value],
			world->f->pixels[value + 1],
			world->f->pixels[value + 2],
			world->f->pixels[value + 3]);
	color = apply_fog(color, fog_strength);
	mlx_put_pixel(imgs->img_3d, dda->ray, tcd->i++, color);
}

void	skybox_drawing(t_imgs *imgs, t_dda *dda, t_sco *tcd, t_swo *world)
{
	int					skybox_tex_x;
	int					skybox_tex_y;
	int					value;
	uint32_t			color;
	static const float	vertical_offset = -89.f * S_H;

	skybox_tex_x = (int)((fmodf(dda->ca + (PI * 2), (PI * 2)))
			/ (PI * 2) * (float)world->p->width) % (int)world->p->width;
	skybox_tex_y = (int)((tcd->i - vertical_offset)
			* ((float)world->p->height / (float)world->p->width));
	if (skybox_tex_y <= 0)
		skybox_tex_y = 0;
	else
		skybox_tex_y %= (int)world->p->height;
	value = (skybox_tex_x + skybox_tex_y * (int)world->p->width) * 4;
	color = g_rgb(world->p->pixels[value],
			world->p->pixels[value + 1],
			world->p->pixels[value + 2],
			world->p->pixels[value + 3]);
	mlx_put_pixel(imgs->img_3d, dda->ray, tcd->i++, color);
}
