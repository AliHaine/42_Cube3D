/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   drawing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/30 23:18:01 by ayagmur           #+#    #+#             */
/*   Updated: 2023/06/30 23:18:03 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   drawing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ngalzand <ngalzand@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/11 16:48:19 by ngalzand          #+#    #+#             */
/*   Updated: 2023/05/11 16:48:26 by ngalzand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/includes.h"

void	draw_energy_bar(mlx_image_t *engbar_texture, int energy, int x, int y)
{
	int			energy_conv;

	energy_conv = energy * 4.3;
	while (y++ != 10)
	{
		if (y == 9 || y == 2)
		{
			x++;
			energy_conv -= 2;
		}
		dpi1(engbar_texture, energy_conv, x, y);
		if (energy < 100)
		{
			if (y == 9 || y == 2)
				energy_conv += 4;
			energy_conv -= 100 * 4.3;
			energy_conv = abs(energy_conv);
			x += energy * 4.3;
			dpi2(engbar_texture, energy_conv, x, y);
		}
		x = 3;
		energy_conv = energy * 4.3;
	}
}

static void	wall_drawing(t_imgs *imgs, t_dda *dda, t_sco *tcd)
{
	if (tcd->f > 1)
		tcd->c = (0 << 24) | (0 << 16) | (0 << 8) | 255;
	else if (tcd->h != '1')
		get_color_block_texture(dda, tcd);
	else if (dda->hit_hv == 1 && dda->hd[0] == 1)
		get_color_wall_texture(imgs->wall_texture[1], (int) dda->r[1], tcd);
	else if (dda->hit_hv == 1 && dda->hd[0] == 3)
		get_color_wall_texture(imgs->wall_texture[3], (int) dda->r[1], tcd);
	else if (dda->hit_hv == 0 && dda->hd[1] == 0)
		get_color_wall_texture(imgs->wall_texture[0], (int) dda->r[0], tcd);
	else
		get_color_wall_texture(imgs->wall_texture[2], (int) dda->r[0], tcd);
	tcd->c = apply_fog(tcd->c, tcd->f);
	mlx_put_pixel(imgs->img_3d, dda->ray, tcd->i++, tcd->c);
	tcd->cu += tcd->s;
}

void	minimap_drawing(t_imgs *i, const float playerpos[2], t_swo *world)
{
	const int		start_y = ((playerpos[1] + world->h) / 4) - (286 / 2);
	const int		start_x = ((playerpos[0] + world->y) / 4) - (286 / 2);
	int				case_xy[2];
	int				p[2];
	static uint32_t	wall_color = (109 << 24) | (96 << 16) | (77 << 8) | 220;

	p[1] = -1;
	while (++p[1] < 286)
	{
		p[0] = -1;
		case_xy[1] = ((p[1] + start_y) / 16);
		while (++p[0] < 286)
		{
			case_xy[0] = ((p[0] + start_x) / 16);
			if ((int)get_pixel(i->m_t, p[0], p[1])
				== -692152577 && (((case_xy[1] < 0 || case_xy[0] < 0
							|| case_xy[1] > (world->h * 3) - 1
							|| case_xy[0] > (world->y * 3) - 1))
					|| (world->w[gcfp(case_xy[0], case_xy[1])]
						[case_xy[1] % world->h][case_xy[0] % world->y] != '0')))
				mlx_put_pixel(i->i_m, p[0], p[1], wall_color);
			else if (get_pixel(i->m_t, p[0], p[1]) != 0)
				i->i_m->pixels[((p[0] + p[1] * i->m_t->width) * 4) + 3] = 220;
		}
	}
}

void	columns_drawing(t_imgs *i, t_dda *dda, t_spl *p, t_options *o)
{
	t_sco			tcd;
	t_swo			*w;

	w = get_world_active();
	setup_col_struct(&tcd, dda, w);
	while (tcd.i < tcd.ce)
	{
		if (o->skybox == true && get_world_active()->m == true)
			skybox_drawing(i, dda, &tcd, w);
		else if (o->skybox == true)
			ceil_drawing(i, dda, &tcd, p);
		else
			mlx_put_pixel(i->img_3d, dda->ray, tcd.i++, w->o[1]);
	}
	while (tcd.i < tcd.w)
		wall_drawing(i, dda, &tcd);
	while (tcd.i < S_H)
	{
		if (o->floor_texture == true)
			floor_drawing(i, dda, &tcd, p);
		else
			mlx_put_pixel(i->img_3d, dda->ray, tcd.i++, w->o[0]);
	}
}
