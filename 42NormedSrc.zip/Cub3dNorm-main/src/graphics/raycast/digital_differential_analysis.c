/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   digital_differential_analysis.c                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/30 00:14:36 by ayagmur           #+#    #+#             */
/*   Updated: 2023/06/30 00:14:38 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/includes.h"

static void	jump_to_next(t_dda *d, const float playerpos[2], bool v)
{
	int		m[2];
	t_swo	*w;

	w = get_world_active();
	while (1)
	{
		m[0] = (int)d->r[0] / 64;
		m[1] = (int)d->r[1] / 64;
		d->c[v] = gcfp(m[0], m[1]);
		if (m[0] >= (w->y * 3) || m[1] >= (w->h * 3) || d->r[0] < 0
			|| d->r[1] < 0 || w->w[d->c[v]][m[1] % w->h][m[0] % w->y] == ' ')
			break ;
		if (w->w[d->c[v]][m[1] % w->h][m[0] % w->y] != '0')
		{
			d->d[v] = d->cos * (d->r[0] - playerpos[0])
				- -d->sin * (d->r[1] - playerpos[1]);
			break ;
		}
		d->r[0] += d->o_xy[0];
		d->r[1] += d->o_xy[1];
	}
}

static void	horizontal_cast(t_dda *dda, float playerpos[2])
{
	float	tan;

	tan = -1.0f / tanf(dda->ca);
	dda->r[0] = playerpos[0];
	dda->r[1] = playerpos[1];
	if (dda->sin > 0.001)
	{
		dda->r[1] = ((int)(playerpos[1] / 64) *64) + 64;
		dda->r[0] = (playerpos[1] - dda->r[1]) * tan + playerpos[0];
		dda->o_xy[1] = 64;
		dda->o_xy[0] = -dda->o_xy[1] * tan;
		dda->hd[1] = 2;
	}
	else if (dda->sin < -0.001)
	{
		dda->r[1] = ((int)(playerpos[1] / 64) *64) - 0.0002;
		dda->r[0] = (playerpos[1] - dda->r[1]) * tan + playerpos[0];
		dda->o_xy[1] = -64;
		dda->o_xy[0] = -dda->o_xy[1] * tan;
		dda->hd[1] = 0;
	}
	if (dda->hd[1] >= 0)
		jump_to_next(dda, playerpos, 0);
}

static void	vertical_cast(t_dda *dda, float playerpos[2])
{
	float	tan;

	tan = -tanf(dda->ca);
	dda->r[0] = playerpos[0];
	dda->r[1] = playerpos[1];
	if (dda->cos > 0.001)
	{
		dda->r[0] = ((int)(playerpos[0] / 64) *64) + 64;
		dda->r[1] = (playerpos[0] - dda->r[0]) * tan + playerpos[1];
		dda->o_xy[0] = 64;
		dda->o_xy[1] = -dda->o_xy[0] * tan;
		dda->hd[0] = 1;
	}
	else if (dda->cos < -0.001)
	{
		dda->r[0] = ((int)(playerpos[0] / 64) *64) - 0.0002;
		dda->r[1] = (playerpos[0] - dda->r[0]) * tan + playerpos[1];
		dda->o_xy[0] = -64;
		dda->o_xy[1] = -dda->o_xy[0] * tan;
		dda->hd[0] = 3;
	}
	if (dda->hd[0] > 0)
		jump_to_next(dda, playerpos, 1);
	dda->v_xy[0] = dda->r[0];
	dda->v_xy[1] = dda->r[1];
}

static void	ray_init(t_dda *dda, float an)
{
	dda->hd[0] = -1;
	dda->hd[1] = -1;
	dda->d[0] = 100000;
	dda->d[1] = 100000;
	dda->hit_hv = 0;
	dda->ca = an + (dda->ray * D_B_R);
	if (dda->ca < 0)
		dda->ca += 6.28319f;
	if (dda->ca > 6.28319f)
		dda->ca -= 6.28319f;
	dda->cos = cosf(dda->ca);
	dda->sin = sinf(dda->ca);
}

void	raycasting(t_spl *player, t_imgs *imgs, t_options *options)
{
	float		start_angle;
	float		dists[S_W];
	t_dda		dda;

	dda.ray = -1;
	start_angle = player->a - (FOV / 2);
	while (dda.ray++ < RAY_NUMBER - 1)
	{
		ray_init(&dda, start_angle);
		vertical_cast(&dda, player->pp);
		horizontal_cast(&dda, player->pp);
		if (dda.d[1] < dda.d[0])
		{
			dda.r[0] = dda.v_xy[0];
			dda.r[1] = dda.v_xy[1];
			dda.d[0] = dda.d[1];
			dda.hit_hv = 1;
			dda.c[0] = dda.c[1];
		}
		dists[dda.ray] = dda.d[dda.hit_hv];
		fisheyes_fixor(&dda, player->a);
		columns_drawing(imgs, &dda, player, options);
	}
	draw_sprites(player, imgs, dists);
}
