/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   raycast_utils.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/27 14:56:49 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/27 14:56:50 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/includes.h"

uint32_t	apply_fog(uint32_t color, float fog_strength)
{
	uint8_t		r;
	uint8_t		g;
	uint8_t		b;
	uint8_t		a;

	if (fog_strength > 1.0)
		fog_strength = 1.0;
	r = ((color >> 24) & 0xFF) * (1.0 - fog_strength);
	g = ((color >> 16) & 0xFF) * (1.0 - fog_strength);
	b = ((color >> 8) & 0xFF) * (1.0 - fog_strength);
	a = (color & 0xFF);
	return ((r << 24) | (g << 16) | (b << 8) | a);
}

void	get_color_wall_texture(mlx_texture_t *w, int r, t_sco *tcd)
{
	int	value;

	value = ((r % w->height) + ((int)tcd->cu * (int)w->width)) * 4;
	if (value >= 16384)
		return ;
	tcd->c = g_rgb(w->pixels[value], w->pixels[value + 1],
			w->pixels[value + 2], w->pixels[value + 3]);
}

void	get_color_block_texture(t_dda *dda, t_sco *tcd)
{
	int			v;
	int			ra;
	mlx_image_t	*b;

	b = get_block_image(gbnfc(tcd->h));
	if (dda->hit_hv == 1)
		ra = (int) dda->r[1];
	else
		ra = (int) dda->r[0];
	if (tcd->h == '(' && (int)mlx_get_time() % 2 == 0)
	{
		v = ((ra % (int) b->height) + ((int) tcd->cu * (int) b->height)
				+ r(3, 0)) * 4;
		if (v >= 16384)
			v = 16000;
	}
	else
		v = ((ra % (int)b->height) + ((int)tcd->cu * (int)b->height)) * 4;
	tcd->c = g_rgb(b->pixels[v], b->pixels[v + 1],
			b->pixels[v + 2], b->pixels[v + 3]);
}

void	fisheyes_fixor(t_dda *dda, float player_angle)
{
	float	two_pi;

	dda->cf = player_angle - dda->ca;
	two_pi = 2 * PI;
	if (dda->cf < 0)
		dda->cf += two_pi;
	if (dda->cf > two_pi)
		dda->cf -= two_pi;
	if (dda->d[0] < 10000)
		dda->d[0] = dda->d[0] * cosf(dda->cf);
}
