/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   struct_drawing.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/14 12:47:12 by ayagmur           #+#    #+#             */
/*   Updated: 2023/07/14 12:47:14 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/includes.h"

static void	s2(t_sco *t, t_dda *d, int convertor)
{
	if (t->w > S_H)
	{
		t->cu = (convertor - S_H) / 2.0;
		t->w = S_H;
	}
	t->cu *= t->s;
	if (d->hit_hv == 1 && d->hd[0] == 3)
		d->r[1] = 63 - ((int)d->r[1] % 64);
	else if (d->hit_hv == 0 && d->hd[1] == 2)
		d->r[0] = 63 - ((int)d->r[0] % 64);
}

void	setup_col_struct(t_sco *t, t_dda *d, t_swo *w)
{
	int	convertor;
	int	wall_height;

	t->w = 0;
	t->i = 0;
	if (d->d[0] >= 10000)
	{
		t->ce = S_H / 2;
		return ;
	}
	wall_height = (S_H * 64) / d->d[0];
	t->ce = (S_H - wall_height) / 2;
	convertor = (64 * S_H) / d->d[0];
	t->w = (S_H + wall_height) / 2;
	t->s = 64.0f / (float)convertor;
	t->cu = 0.0f;
	t->f = d->d[d->hit_hv] / FOG_DISTANCE;
	t->h = w->w[d->c[0]][((int)d->r[1] / 64)
		% w->h][((int)d->r[0] / 64) % w->y];
	s2(t, d, convertor);
}
