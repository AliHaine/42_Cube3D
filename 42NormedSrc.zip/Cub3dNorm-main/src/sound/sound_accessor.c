/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sound_accessor.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ayagmur <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/26 18:51:32 by ayagmur           #+#    #+#             */
/*   Updated: 2023/08/26 18:51:33 by ayagmur          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/sound.h"

static t_sso	g_sounds[SO9];

t_sso	*get_sound(t_eso sound)
{
	return (&g_sounds[sound]);
}

void	set_sound(t_sso sound)
{
	g_sounds[sound.n] = sound;
}
